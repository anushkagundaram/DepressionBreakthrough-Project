import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-musictherapy',
  templateUrl: './musictherapy.component.html',
  styleUrls: ['./musictherapy.component.css']
})
export class MusictherapyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
